--table customer_master for customer details 

CREATE TABLE customer_master
(
customer_id VARCHAR(6),
customer_name VARCHAR(30),
contact_no VARCHAR(10), 
contact_address VARCHAR(30),
date_of_registration DATE,
age INT(3),
CONSTRAINT customer_master_customer_id_pk PRIMARY KEY(customer_id)
);

--table movie_master for movie details 

CREATE TABLE movies_master
(
movie_id VARCHAR(6),
movie_name VARCHAR(30),
release_year INT(4),
language VARCHAR(15),
rating INT(1),
duration_in_minutes INT(3),
movie_type VARCHAR(20), 
movie_category VARCHAR(30),
director_name VARCHAR(30),
lead_actor_name1 VARCHAR(40),
lead_actor_name2 VARCHAR(40),
rental_cost INT(3),
CONSTRAINT movies_master_movie_id_pk PRIMARY KEY(movie_id)
);


--table library_card_master for storing card details

CREATE TABLE library_card_master
(
card_id VARCHAR(6),
description VARCHAR(30),
amount INT(4),
number_of_years INT(1),
CONSTRAINT library_card_master_card_id_pk PRIMARY KEY(card_id)
);


--table customer_issue_details for storing customer issue details

CREATE TABLE customer_issue_details
(
issue_id VARCHAR(6),
customer_id VARCHAR(6),
movie_id  VARCHAR(6),
issue_date DATE,
return_date DATE,
actual_date_of_return DATE,
CONSTRAINT customer_issue_details_issue_id_pk PRIMARY KEY(issue_id),
CONSTRAINT customer_issue_details_customer_id_fk FOREIGN KEY(customer_id) REFERENCES customer_master(customer_id),
CONSTRAINT customer_issue_details_movie_id_fk FOREIGN KEY(movie_id) REFERENCES movies_master(movie_id)
);


--table customer_card_details for storing  customer and type of cards they being issued


CREATE TABLE customer_card_details
(
customer_id VARCHAR(6),
card_id VARCHAR(6), 
issue_date DATE,
CONSTRAINT customer_card_details_customer_id_fk FOREIGN KEY(customer_id) REFERENCES customer_master(customer_id),
CONSTRAINT customer_card_details_customer_id_fk FOREIGN KEY(card_id) REFERENCES library_card_master(card_id),
);



